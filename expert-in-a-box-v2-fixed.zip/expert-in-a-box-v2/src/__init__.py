# Expert-in-a-Box V2
__version__ = "0.1.0"
